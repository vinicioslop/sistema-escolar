namespace sistema_escolar.console
{
    public enum Ano
    {
        SEGUNDO_ANO = 1,
        TERCEIRO_ANO = 2,
        QUARTO_ANO = 3,
        QUINTO_ANO = 4,
        SEXTO_ANO = 5,
        SETIMO_ANO = 6,
        OITAVO_ANO = 7,
        NONO_ANO = 8
    }
}