namespace sistema_escolar.console
{
    public enum Status
    {
        CURSANDO = 1,
        APROVADO = 2,
        RECUPERACAO = 3,
        REPROVADO = 4
    }
}