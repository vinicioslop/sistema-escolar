namespace sistema_escolar.console
{
    public enum Disciplina
    {
        PORTUGUES = 1,
        MATEMATICA = 2,
        HISTORIA = 3,
        GEOGRAFIA = 4,
        CIENCIAS = 5,
        EDUCACAO_FISICA = 6,
        ARTES = 7
    }
}